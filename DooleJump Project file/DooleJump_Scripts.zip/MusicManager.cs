﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 背景音乐
/// </summary>
public class MusicManager : MonoSingleton<MusicManager>
{
    AudioSource ad;
    public AudioClip bg;
    public bool isGameOver = false;//游戏是否结束

    protected override void Awake()//重写Awake()
    {
        base.Awake();
        ad = GetComponent<AudioSource>();
        PlayMusic();
    }

    public void PlayMusic()
    {
        ad.clip = bg;
        ad.Play();
    }

    private void Update()//可以看出GameOver之后，音调并没有升回来，所以重新加载场景一切都刷新了
    {
        //播放失败音效
        if (isGameOver)
        {
            if (ad.pitch > 0.4f)
                //降低音调
                ad.pitch -= Time.deltaTime * 0.5f;
            else
                isGameOver = false;
        }
    }

}
