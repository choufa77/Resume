﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UI_InGame : MonoBehaviour
{
    public Text txt_Coin;
    public Text txt_Score;
    public GameObject white;

    //暂停游戏
    public void OnBtnPause()
    {
        GUIManager.Instance.OpenPanel(2);//打开暂停界面，不过bool isHidePrevious = false，即不删除当前Panel
        GameManager.Instance.gameState = GameState.PAUSED;//设置游戏状态
        Time.timeScale = 0;//暂停时间
        SoundManager.Instance.PlaySFX(0);

    }

    private void OnEnable()
    {
        // OnEnable()被调用时，清零
        txt_Coin.text = "0";
        txt_Score.text = "0";

    }

    //更新金币数至InGame界面的UI
    public void UpdateCoin(int value)
    {
        txt_Coin.text = value.ToString();
    }
    //更新分数
    public void UpdateScore(int value)
    {
        txt_Score.text = value.ToString();

    }
    /// <summary>
    /// 显示白色背景
    /// </summary>
    public void ShowFlash()//闪白
    {
        StartCoroutine(ShowFlashing())//开始协程
;
    }

    IEnumerator ShowFlashing()//用到协程的原因是 等几秒
    {
        white.SetActive(true);//激活，白色一闪而过
        yield return new WaitForSeconds(0.4f);
        white.SetActive(false);

    }
}
