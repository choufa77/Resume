﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UI_GameOver : MonoBehaviour
{
    public Text txt_Best;
    public Text txt_Score;
    public void OnBtnReturn()
    {
        SceneManager.LoadScene(0);  //游戏结束，重新加载最初场景
        
        /// <summary>
        /// GUIManager.Instance.OpenPanel(0, true);  
        /// 之所以不用这个，用上面LoadScene(0)，是因为上面那个能重新加载场景，故重新调用GameManager单例的Awake()Start()等代码，
        /// 包括其他脚本的Awake()Start()等，就如点开时一样，从头到尾加载。
        /// </summary>


        SoundManager.Instance.PlaySFX(0);//播放点击音效
    }


    private void OnEnable()
    {
        txt_Best.text = PlayerPrefs.GetInt("BestScore", 0).ToString();//记录最高分数，否则就默认值0分
        txt_Score.text = GameManager.Instance.Score.ToString();//YourScore
    }
}
