﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_Pause : MonoBehaviour
{
    //此界面包含有UI_InGame界面里的所有UI，所以也定义以下两个text，并更新数量
    public Text txt_Coin;
    public Text txt_Score;

    private void OnEnable()//每次激活时——即每次暂停时，都要同步金币与分数
    {
        txt_Coin.text = GameManager.Instance.Coin.ToString();
        txt_Score.text = GameManager.Instance.Score.ToString();
    }

    //返回游戏
    public void OnBtnReturn()//恢复暂停
    {
        GameManager.Instance.gameState = GameState.RUNNING;//游戏状态恢复为RUNNING
        Time.timeScale = 1;//恢复原本时间流速
        GUIManager.Instance.Back();//返回上一Panel
        SoundManager.Instance.PlaySFX(0);//播放音效

    }
}
