﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_Skin : MonoBehaviour
{
    public Text txt_Coin;//玩家所拥有的金币数
    public List<GameObject> skinItems = new List<GameObject>();//获取 skinItems数据
    //实例化了脚本
    public UI_Main UIMain;


    public void OnBtnReturn()//返回，Button调用
    {
        GUIManager.Instance.Back();
        SoundManager.Instance.PlaySFX(0);

    }
    //private void Awake()
    //{
    //    Debug.Log("UI_Skin.Awake()方法调用");
    //}

    private void OnEnable()//放到OnEnable()而不是Start()，是因为这些数据,在每次皮肤UI被激活后，都要更新
    {
        //PlayerPrefs.DeleteAll();//金手指
        RefreshList();
        Init();

        //Debug.Log("UI_Skin.OnEnable()方法调用");
    }
    //private void Start()
    //{
    //    //PlayerPrefs.DeleteAll();//金手指

    //    //Debug.Log("UI_Skin.Start()方法调用");
    //}

    /// <summary>
    /// PlayerPrefs.GetInt(key,defaultValue)中的defaultValue参数非常有用，
    ///     因为玩家第一次玩的时候存档还没有建立。所以需要使用defaultValue参数，相当于为playerPrefs进行初始化。
    /// </summary>
    void Init()//更新Skin界面的金币数显示
    {
        //txt_Coin = transform.Find("Text_Coin").GetComponent<Text>();可用此等方法赋值，也可以直接在Inspector里赋值(即现在用的）
        txt_Coin.text = PlayerPrefs.GetInt("Coin", 100).ToString();
        //int GetInt(string key, int defaultValue);
        //返回偏好设置文件中与 key 对应的值（如果存在）;如果不存在，则返回 / defaultValue /。

        //PlayerPrefs.GetInt(key,defaultValue)中的defaultValue参数非常有用，
        //   因为玩家第一次玩的时候存档还没有建立。所以需要使用defaultValue参数，相当于为playerPrefs进行初始化。
    }

    private void Update()//外挂
    {
        if (Input.GetKeyDown(KeyCode.A))//每按一下“A”，金币数直接变10000
        {
            PlayerPrefs.SetInt("Coin", 10000);
            Init();
        }
        if (Input.GetKeyDown(KeyCode.B))//每按一下“B”，金币数清零
        {
            PlayerPrefs.SetInt("Coin", 0);
            Init();
        }
        if (Input.GetKeyDown(KeyCode.D))//每按一下“D”，所有存储值清零
        {
            PlayerPrefs.DeleteAll();  //金手指
            UIMain.ChangeSkin();//刷新Main界面的player皮肤
            Init();//更新Skin界面的金币数显示
            RefreshList();//刷新skinItems数据（价格、解锁状态、名字}
        }
    }

    /// <summary>
    /// 更新显示
    /// </summary>
    void RefreshList()//刷新skinItems数据（价格、解锁状态、名字}
    {
        for (int i = 0; i < SkinManager.Instance.Skins.Count; i++)//一个个赋值给skinItems（共五个）
        {
            //将Skins[i]里的皮肤数据 赋给，对应的skinItems[i]的子物体"Image_Character"里的<Image>，显示皮肤
            skinItems[i].transform.Find("Image_Character").GetComponent<Image>().sprite
        = SkinManager.Instance.Skins[i].spriteCharacter;

            //判断有没有解锁 0 lock 1 Unlock
            if (PlayerPrefs.GetInt("isSkin" + i + "UnLocked", 0) == 0 && !SkinManager.Instance.Skins[i].isDefauleLock)
            //如果从历史保存的数据看，是没解锁的；且也默认没解锁的
            //这么看，第一个默认皮肤的，也会被赋予“0”，所以才需要isDefauleLock这种默认值为“true",且是用了“并”！
            //    ——不懂了，这是GetInt，不是SetInt，怎么赋值呢？？——答案是：玩家第一次玩的时候存档还没有建立，就会用defaultValue参数初始化
            {
                //赋值 金币 图片

                //显示价格
                skinItems[i].transform.Find("Image_Coin").gameObject.SetActive(true);//找到对应下的skinItems[i]里的子物体"Image_Coin"并激活

                //更新价格
                skinItems[i].transform.Find("Image_Coin/Text_Coin").GetComponent<Text>().text = SkinManager.Instance.Skins[i].price.ToString();
                //找到子物体的子物体——("Image_Coin/Text_Coin")
            }
            else//已经解锁了的，且包括默认已解锁的
            {
                //解锁了就隐藏掉价格，即"Image_Coin"
                skinItems[i].transform.Find("Image_Coin").gameObject.SetActive(false);

            }
            //每个skinItems被赋予0至4的名字
            skinItems[i].name = i.ToString();
        }
    }

    /// <summary>
    /// 鼠标点击
    /// </summary>
    /// <param name="id">当前选择物体</param>
    public void OnBtnClick(GameObject id)//Button点击事件，(GameObject id)已传过来
    {
        foreach (var skins in skinItems)//遍历  不允许声明var“skin” 为局部变量！！！！！！
        {
            if (skins == id)
                skins.GetComponent<Move>().Resume();
            else
                skins.GetComponent<Move>().Pause();
        }

        //得到当前点击皮肤的信息（价格等）
        SkinManager.Skin skin = SkinManager.Instance.Skins[int.Parse(id.name)];

        if (skin.isDefauleLock || PlayerPrefs.GetInt("isSkin" + int.Parse(id.name) + "UnLocked", 0) == 1)//默认解锁的、已经解锁的，故用“或”
        {
            //皮肤已经购买

            //确定选择的皮肤，且刷新skinItems转态，以及完成换主菜单里的player装
            SelectSkin(int.Parse(id.name));
            SoundManager.Instance.PlaySFX(7);

        }
        else
        {
            //判断可不可以买
            if (skin.price <= PlayerPrefs.GetInt("Coin", 100))//如果可以买
            {
                //更新钱币数
                PlayerPrefs.SetInt("Coin", PlayerPrefs.GetInt("Coin", 100) - skin.price);
                //当前皮肤已经买了
                PlayerPrefs.SetInt("isSkin" + int.Parse(id.name) + "UnLocked", 1);//该解锁状态为1
                SelectSkin(int.Parse(id.name));//确定选择的皮肤，且刷新，完成换主菜单里的player装
                Init();//更新Skin界面的金币数显示
                //Debug.Log("成功购买！" + id.name);
                SoundManager.Instance.PlaySFX(2);

            }
            else
            {
                //Debug.Log("买不起，当前金币数："+ PlayerPrefs.GetInt("Coin", 100));
                SoundManager.Instance.PlaySFX(4);

            }
        }
    }

    void SelectSkin(int id)//确定选择的皮肤  GameManager有一个跟他名字一样方法（作用：换Player身上的装，且是公有的），而这是默认私有
    {
        PlayerPrefs.SetInt("selectSkin", id);//存储已经购买的皮肤
        RefreshList();//刷新skinItems数据（价格、解锁状态、名字}
        //Debug.Log("已买，");

        //换主菜单里的player装
        UIMain.ChangeSkin();
    }
}
