﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UI_Main : MonoBehaviour
{
    //得到Main里player的Image组件，以便换Main中player的皮肤
    public Image player;

    public void OnBtnPlay()//开始游戏，打开InGame图层，并激活player改游戏状态RUNNING
    {
        GUIManager.Instance.OpenPanel(1, true);

        //激活player改游戏状态RUNNING
        GameManager.Instance.PlayGame();

        SoundManager.Instance.PlaySFX(0);

    }


    public void OnBtnSkin()
    {
        GUIManager.Instance.OpenPanel(4);
        SoundManager.Instance.PlaySFX(0);

    }

    public void ChangeSkin()//换主菜单里的player装
    {
        player.GetComponent<Image>().sprite = SkinManager.Instance.Skins[PlayerPrefs.GetInt("selectSkin", 0)].spriteCharacter;

    }

    private void Start()
    {
        ChangeSkin();//换主菜单里的player装,因为Start()，故一开始就从这里赋初始值了，即上面的“0”
    }
}
