﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// UI框架
/// </summary>
public class GUIManager : MonoSingleton<GUIManager>//继承自MonoSingleton
{

    //面板资源
    public List<GameObject> panels;//列表List，是一个泛型集合，

    public Stack<GameObject> panelStack = new Stack<GameObject>();//Stack堆栈；作用：实现Panel的跳转

    public int currentNumber;

    /// <summary>
    /// 当前面板
    /// </summary>
    public GameObject currentPanelObj//当前 Stack 的顶部
    {
        get
        {
            return panelStack.Peek();//Peek()，返回在 Stack 的顶部的对象，但不移除它
        }
    }

    private void OnEnable()
    {
        OpenPanel(currentNumber);
    }

    /// <summary>
    /// 打开面板
    /// </summary>
    /// <param name="id">面板index</param>
    /// <param name="isHidePrevious">是否删除之前的面板</param>
    public void OpenPanel(int id, bool isHidePrevious = false)//打开Panel
    {
        //A、B 毫无瓜葛
        if (isHidePrevious)//如果要隐藏上一个Panel
        {
            if (panelStack.Peek() != null)
            {
                currentPanelObj.SetActive(false);//隐藏Panel
                panelStack.Pop();//Pop()，移除并返回在 Stack 的顶部的对象
            }
            panelStack.Push(panels[id]);//Push( obj )，向 Stack 的顶部添加一个对象
            currentPanelObj.SetActive(true);//打开Panel
        }
        else//
        {
            panelStack.Push(panels[id]);//放入Panel
            currentPanelObj.SetActive(true);//激活Panel
        }
    }

    //返回前一页
    public void Back()
    {
        if (panelStack.Peek() != null)
        {
            currentPanelObj.SetActive(false);//隐藏当前Panel
            panelStack.Pop();//移除
        }
        currentPanelObj.SetActive(true);//返回后的Panel就可以打开了

    }

}
