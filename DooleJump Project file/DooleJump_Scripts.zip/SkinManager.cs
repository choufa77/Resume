﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;//[Serializable]要用到
public class SkinManager : MonoSingleton<SkinManager>
{
    /// <summary>
    /// 皮肤数据
    /// </summary>
    [Serializable]//可序列化
    public class Skin
    {
        public int price;
        //是否默认解锁
        public bool isDefauleLock = false;
        public Sprite spriteCharacter;
    }

    public List<Skin> Skins = new List<Skin>();//类的集合
}
