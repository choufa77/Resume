﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;//引用命名空间

//游戏设置
[Serializable]//可序列化的
public class GameSetting
{

    [Serializable]
    public class NormalTile
    {
        public float minHeight;
        public float maxHeight;
        //生成权值
        public float weight;
    }


    [Serializable]
    public class BrokenTile
    {
        public float minHeight;
        public float maxHeight;
        public float weight;
    }


    [Serializable]
    public class OneTimeOnly
    {
        public float minHeight;
        public float maxHeight;
        public float weight;
    }


    [Serializable]
    public class SpringTile
    {
        public float minHeight;
        public float maxHeight;
        public float weight;
    }


    [Serializable]
    public class MovingHorizontally
    {
        public float minHeight;
        public float maxHeight;
        public float distance;
        public float speed;
        public float weight;
    }


    [Serializable]
    public class MovingVertically
    {
        public float minHeight;
        public float maxHeight;
        public float distance;
        public float speed;
        public float weight;
    }

    public NormalTile normalTile;
    public BrokenTile brokenTile;
    public OneTimeOnly oneTimeOnly;
    public SpringTile springTile;
    public MovingHorizontally movingHorizontally;
    public MovingVertically movingVertically;

    //生成item概率
    public float itemProbability;
    //生成coin概率
    public float coinProbability;
    //生成enemy概率
    public float enemyProbability;
}
