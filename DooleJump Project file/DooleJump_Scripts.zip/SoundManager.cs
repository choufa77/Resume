﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoSingleton<SoundManager>
{
    //音频数组
    public AudioClip[] sfx;

    AudioSource ad;
    protected override void Awake()//重写Awake()
    {
        base.Awake();
        ad = GetComponent<AudioSource>();//获取组件
    }

    public void PlaySFX(int id)
    {
        ad.PlayOneShot(sfx[id]);//播放数组对应序号的音频
    }

    //停止音效，因为PowerUp的飞行时间停止后，音频由于过长，导致还在响
    public void StopSFX()
    {
        ad.Stop();
    }
}
