﻿//    这段代码定义了一个抽象的泛型基类 MonoSingleton<T>，(——单例模板)
//    它继承自 UnityEngine 命名空间下的 MonoBehaviour，旨在为基于 Unity 开发时创建单例模式（Singleton Pattern）的脚本组件提供一个通用的基础模板。
//    单例模式的核心就是保证在整个程序运行过程中，某个类只有一个实例存在，并且提供一个方便获取该实例的途径，在这里通过 Instance 属性来实现这一功能。
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class MonoSingleton<T> : MonoBehaviour//这里定义了一个抽象的泛型类 MonoSingleton<T>，它继承自 MonoBehaviour。abstract 关键字表明这个类是抽象的，
                                                      //意味着它不能被直接实例化，
                                                      //而是需要由其他具体的类去继承它并实现其未完全定义的部分（比如抽象方法等，不过这里暂时没有抽象方法展示）。
    where T: MonoBehaviour                           //泛型类型参数<T> 用于让继承这个基类的具体类来指定实际的类型，
                                                      //同时通过 where T : MonoBehaviour 这个泛型约束，
                                                     //限定了 T 必须是继承自 MonoBehaviour 的类型，确保后续使用时这个泛型类型符合 Unity 脚本组件的要求。
{
    static T m_instance;
    //声明了一个静态变量 m_instance，类型为泛型 T，它用于存储单例模式下唯一的实例对象。
    //由于是静态变量，其生命周期贯穿整个程序运行期间，并且在类的所有实例间共享，这符合单例模式中只存在一个实例的要求。

    public static T Instance { get => m_instance; }
    //定义了一个公共的静态只读属性 Instance，其作用是对外提供获取单例实例的接口。
    //通过这个属性，外部代码可以方便地获取到当前单例类的唯一实例对象，它采用了简洁的表达式主体定义（Expression-bodied member）形式，
    //直接返回 m_instance 的值。

    //Awake 方法重写
    protected virtual void Awake()
    {
        m_instance = this as T;
    }
    //重写了 MonoBehaviour 中的 Awake 方法，Awake 方法是 Unity 生命周期函数中的一个，会在脚本实例被加载（也就是游戏对象挂载该脚本组件时）初始化阶段被调用一次。
    //在这个重写的 Awake 方法里，将当前脚本实例（通过 this 关键字表示）强制转换为泛型类型 T 并赋值给 m_instance，
    //目的是在脚本组件初始化时，确保 m_instance 存储了正确的单例实例对象。
    //不过这里存在一个潜在问题，如果有多个继承自 MonoSingleton<T> 的脚本同时存在并被加载，
    //后加载的脚本会覆盖之前存储在 m_instance 中的实例，可能导致不符合预期的行为，
    //通常还需要额外添加逻辑来确保单例的唯一性，比如判断 m_instance 是否已经被赋值等情况。
}

//总体而言，这段代码搭建了一个在 Unity 中创建单例脚本组件的基础框架，但要完善地应用在实际项目中，可能还需要对单例的初始化、唯一性保障等方面做进一步的优化和扩展。


