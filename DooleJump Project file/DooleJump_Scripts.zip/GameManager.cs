﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoSingleton<GameManager>
{
    //tile池子
    public Queue<GameObject> tilePool = new Queue<GameObject>();
    public Queue<GameObject> coinPool = new Queue<GameObject>();
    public Queue<GameObject> bulletPool = new Queue<GameObject>();
    public Queue<GameObject> enemyPool = new Queue<GameObject>();
    public Queue<GameObject> itemPool = new Queue<GameObject>();

    //tile样本 为了第49行代码
    public GameObject tilePrefab;
    public GameObject coinPrefab;
    public GameObject bulletPrefab;
    public GameObject enemyPrefab;
    public GameObject itemPrefab;

    //游戏状态
    public GameState gameState = GameState.PAUSED;
    //透明图片，回收阈值
    public GameObject floor;
    //数据设置
    public GameSetting Advance;//实例化
    //除tile外，其他object的parent
    public Transform parent;
    //子弹生成位置
    public Transform bulletSpawnPos;
    //player玩家
    public GameObject player;
    //UI面板
    public UI_InGame UIInGame;

    int coin;
    int score;

    //一次性生成tile的初始数量
    int initialSize = 40;
    //总权值
    float totalSum;
    float currentY = -6;//第一个tile应当生成的高度，-6是根据本项目实际情况赋值的
    //上一次时间
    float lastTime;

    //封装字段并使用属性
    public int Coin
    {
        get
        {
            return coin;
        }

        set
        {
            coin = value;
            //更新UI
            UIInGame.UpdateCoin(value);           
        }
    }

    public int Score
    {
        get
        {
            return score;
        }

        set
        {
            score = value;
            UIInGame.UpdateScore(value);

        }
    }

    protected override void Awake()//重写，此代码没用
    {
        base.Awake();
        //Debug.Log("GameManager.Awake()方法调用");
    }

    private void Start()
    {
        //if (Input.GetKeyDown(KeyCode.D))//每按一下“D”，所有存储值清零
        //{
        //    PlayerPrefs.DeleteAll();  //金手指
        //}
        //PlayerPrefs.DeleteAll();  //金手指

        //为了得到总权值totalSum
        GetAllWeight();

        //初始化对象池
        GenerateTilePool();
        GenerateBulletPool();
        GenerateCoinPool();
        GenerateEnemyPool();
        GenerateItemPool();
        //Debug.Log(itemPool.Count + "  " + tilePool.Count + " " + coinPool.Count + "  " + bulletPool.Count + " " + enemyPool.Count);输出60 60 60 60

        //Debug.Log(totalSum);

        //一个个生成物体，或者说一个个把物体从Pool放出来
        for (int i = 0; i < initialSize; i++)
        {
            GenerateTile();
            GenerateItem();
            GenerateEnemy();
            GenerateCoin();
        }

        // 换装player的
        SelectSkin();

        //Debug.Log("GameManager.Start()方法调用");
    }

    public void PlayGame()
    {
        player.SetActive(true);//游戏开始才激活Player
        gameState = GameState.RUNNING;
        //读取皮肤
    }

    #region 初始化以及随机生成
    //生成Tile池子
    void GenerateTilePool()
    {
        for (int i = 0; i < initialSize; i++)
        {
            GameObject go = Instantiate(tilePrefab, transform);//以tilePrefab为模板生成tile例子，放在transform父物体下（即本脚本挂载的GameManager)
            go.SetActive(false);//不激活
            go.name = i.ToString();//给生成的tile命名，为0-60
            tilePool.Enqueue(go);//入队，即放入池子
        }
    }
    void GenerateItemPool()
    {
        for (int i = 0; i < initialSize; i++)
        {
            GameObject go = Instantiate(enemyPrefab, parent);//以tilePrefab为模板生成tile例子，放在transform父物体下（即本脚本挂载的GameManager)
            go.SetActive(false);//不激活
            go.name = i.ToString();//给生成的tile命名，为0-60
            enemyPool.Enqueue(go);//入队，即放入池子
        }
    }

    void GenerateCoinPool()
    {
        for (int i = 0; i < initialSize; i++)
        {
            GameObject go = Instantiate(itemPrefab, parent);//以tilePrefab为模板生成tile例子，放在transform父物体下（即本脚本挂载的GameManager)
            go.SetActive(false);//不激活
            go.name = i.ToString();//给生成的tile命名，为0-60
            itemPool.Enqueue(go);//入队，即放入池子
        }
    }
    void GenerateEnemyPool()
    {
        for (int i = 0; i < initialSize; i++)
        {
            GameObject go = Instantiate(coinPrefab, parent);//以tilePrefab为模板生成tile例子，放在transform父物体下（即本脚本挂载的GameManager)
            go.SetActive(false);//不激活
            go.name = i.ToString();//给生成的tile命名，为0-60
            coinPool.Enqueue(go);//入队，即放入池子
        }
    }
    void GenerateBulletPool()
    {
        for (int i = 0; i < initialSize; i++)
        {
            GameObject go = Instantiate(bulletPrefab, parent);//以tilePrefab为模板生成tile例子，放在transform父物体下（即本脚本挂载的GameManager)
            go.SetActive(false);//不激活
            go.name = i.ToString();//给生成的tile命名，为0-60
            bulletPool.Enqueue(go);//入队，即放入池子
        }
    }
    //随机砖块
    void GenerateTile()//本函数是一个个取出tile,故涉及到的对象都是单独的个体
    {
        //在队列取出“砖块”
        GameObject go = GetInactiveObject(ObjectType.Tile);
        //得出随机数
        float rand = Random.Range(0, totalSum);
        //得到返回值0、1、2、3、4、5；确定了tile的种类
        int randNumber = SetTileByRandomNumber(rand);

        //限制了tile二位坐标的x、y范围
        Vector2 pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);

        //根据返回值，确定生成物体的位置、name、类型并激活它
        switch (randNumber)
        {
            case 0:

                currentY += Random.Range(Advance.normalTile.minHeight, Advance.normalTile.maxHeight);//开始随机Y方向上的值
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);//有了这行，才能确定上一行的Y值被赋在了本次生成的tile，而不是下一个
                go.transform.position = pos;//确定这个tile的位置
                go.name = "0";//对池子里要激活的物体重命名
                go.SetActive(true);//激活
                break;
            case 1:

                currentY += Random.Range(Advance.brokenTile.minHeight, Advance.brokenTile.maxHeight);
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);
                go.transform.position = pos;
                go.name = "1";
                go.SetActive(true);
                break;
            case 2:

                currentY += Random.Range(Advance.oneTimeOnly.minHeight, Advance.oneTimeOnly.maxHeight);
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);
                go.transform.position = pos;
                go.name = "2";
                go.SetActive(true);
                break;
            case 3:

                currentY += Random.Range(Advance.springTile.minHeight, Advance.springTile.maxHeight);
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);
                go.transform.position = pos;
                go.name = "3";
                go.SetActive(true);
                break;
            case 4:

                currentY += Random.Range(Advance.movingHorizontally.minHeight, Advance.movingHorizontally.maxHeight);
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);
                go.transform.position = pos;
                go.name = "4";
                go.SetActive(true);
                break;
            case 5:

                currentY += Random.Range(Advance.movingVertically.minHeight, Advance.movingVertically.maxHeight);
                pos = new Vector2(Random.Range(-4.3f, 4.2f), currentY);
                go.transform.position = pos;
                go.name = "5";
                go.SetActive(true);
                break;
            default:
                break;
        }

    }

    //随机item
    void GenerateItem()//生成道具
    {
        float rand = Random.Range(0f, 1f);//随机出一个数
        if (rand < Advance.itemProbability)//随机数小于规定的0.03——实现了概率问题
        {
            GameObject randGo = null;

            //while (true)//  这个循环贼不靠谱，虽然不是死循环，但是运气差的话跟死循环差不多，
            //    //因为这个Random.Range()是随机的，不是遍历，就有可能一直随机出一个不满足退出循环的数，导致很卡，真的卡死了！！！！！！！！！！
            //{
            //    randGo = transform.GetChild(Random.Range(0, initialSize)).gameObject;//randGo =GameManager下的tile物体

            //    //要确保道具的生成位置不是移动中的tile，并且为了游戏体验，不会游戏开始就拥有道具
            //    if (randGo.GetComponent<Tile>().tileType < 4 && randGo.transform.position.y > 5)
            //        break;//只要筛出的数字满足以上两个条件就退出循环
            //}

            randGo = transform.GetChild(Random.Range(0, initialSize)).gameObject;//randGo =GameManager下的tile物体
            GameObject go = GetInactiveObject(ObjectType.Item);//取出Item
            go.name = Random.Range(0, 2).ToString();//随机出整数0或1，也就随机出是螺旋桨还是火箭
            go.SetActive(true);//激活
            go.transform.position = randGo.transform.position + new Vector3(0, 0.5f, 0);//生成出的道具位置要在随机出的tile0.5以上位置
        }
    }

    /// <summary>
    /// 随机怪物，本函数是一个个取出enemy
    /// </summary>
    void GenerateEnemy()
    {
        float rand = Random.Range(0f, 1f);//随机数，获得概率
        if (rand < Advance.enemyProbability)//满足概率
        {
            ////GenerateTile()里的currentY赋值过来，x随机，这样会导致生成的enemy在Y方向上有一个tile保持同一水平高度
            Vector2 pos = new Vector2(Random.Range(-4.5f, 4.5f), currentY);
            GameObject go = GetInactiveObject(ObjectType.Enemy);//在队列里一个个取出enemy
            go.name = Random.Range(0, 3).ToString();//随机出一个整数：0,1,2，
            go.transform.position = pos;//确定位置
            go.SetActive(true);//激活
        }
    }

    /// <summary>
    /// 随机金币
    /// </summary>
    void GenerateCoin()
    {
        float rand = Random.Range(0f, 1f);
        if (rand < Advance.coinProbability)
        {
            Vector2 pos = new Vector2(Random.Range(-4.5f, 4.5f), currentY);
            GameObject go = GetInactiveObject(ObjectType.Coin);
            go.name = "Coin";
            go.transform.position = pos;
            go.SetActive(true);
        }
    }
    #endregion

    //判断“随机数”处于哪个权值区里，进而返回0,1,2,3……
    int SetTileByRandomNumber(float number)
    {
        if (number <= Advance.normalTile.weight)
            return 0;
        else if (number <= Advance.normalTile.weight + Advance.brokenTile.weight)
            return 1;
        else if (number <= Advance.normalTile.weight + Advance.brokenTile.weight + Advance.oneTimeOnly.weight)
            return 2;
        else if (number <= Advance.normalTile.weight + Advance.brokenTile.weight + Advance.oneTimeOnly.weight + Advance.springTile.weight)
            return 3;
        else if (number <= Advance.normalTile.weight + Advance.brokenTile.weight + Advance.oneTimeOnly.weight + Advance.springTile.weight + Advance.movingHorizontally.weight)
            return 4;
        else if (number <= Advance.normalTile.weight + Advance.brokenTile.weight + Advance.oneTimeOnly.weight + Advance.springTile.weight + Advance.movingVertically.weight + Advance.movingHorizontally.weight)
            return 5;

        return -1;

    }

    #region 对象池
    //从池子取物体（未经处理的）在GenerateTile()里调用的
    public GameObject GetInactiveObject(ObjectType type)
    {
        switch (type)
        {
            case ObjectType.Tile:
                return tilePool.Dequeue();//Dequeue()出队
            case ObjectType.Item:
                return itemPool.Dequeue();
            case ObjectType.Coin:
                return coinPool.Dequeue();
            case ObjectType.Enemy:
                return enemyPool.Dequeue();
            case ObjectType.Bullet:
                GameObject go = bulletPool.Dequeue();
                go.transform.position = bulletSpawnPos.position;
                go.SetActive(true);
                return go;
            default:
                return null;
        }
    }

    //回收砖块、道具等
    public void AddInActiveObjectToPool(GameObject go, ObjectType type)
    {
        go.SetActive(false);
        //先隐藏再回收进各自专属的池子
        switch (type)
        {
            case ObjectType.Tile:
                tilePool.Enqueue(go);//入队
                //当一个tile销毁时，调用此方法（包含有GenerateTile()等）,能实现不同于Start()里的GenerateTile()只能在初始调用，这被回收时就调用
                CreateTile();//即每当有一个tile被回收后,就同时有一个tile、item、enemy、coin生成
                break;
            case ObjectType.Item:
                itemPool.Enqueue(go);
                break;
            case ObjectType.Coin:
                coinPool.Enqueue(go);
                break;
            case ObjectType.Enemy:
                enemyPool.Enqueue(go);
                break;
            case ObjectType.Bullet:
                bulletPool.Enqueue(go);
                break;
            default:
                break;
        }
    } 
    #endregion

    //当一个tile销毁时，调用此方法
    void CreateTile()
    {
        if (gameState!=GameState.GAMEOVER)
        {
            GenerateTile();
            GenerateItem();
            GenerateEnemy();
            GenerateCoin();
            IncreaseDifficult(5);//当有tile被回收时，才开始此代码
            Score += 5;
            
        }
    }

    //难度曲线
    void IncreaseDifficult(float time)//间隔 time秒增加难度
    {
        if (Time.time - lastTime > time)
        {
            lastTime = Time.time;
            Advance.enemyProbability += 0.01f;//大约5秒增加一次难度
            //Debug.Log("IncreaseDifficult");
        }
    }

    //获取权值所有
    void GetAllWeight()//为什么不一次性加？
    {
        float sum = 0;
        sum += Advance.normalTile.weight;
        sum += Advance.brokenTile.weight;
        sum += Advance.oneTimeOnly.weight;
        sum += Advance.springTile.weight;
        sum += Advance.movingHorizontally.weight;
        sum += Advance.movingVertically.weight;
        totalSum = sum;
    }

    public void EndGame()
    {
        if (gameState!=GameState.GAMEOVER)
        {
            gameState = GameState.GAMEOVER;//1.更新游戏状态

            //特效系列
            //2.相机抖动
            iTween.ShakePosition(Camera.main.gameObject, new Vector3(0.7f, 0.7f, 0), 0.5f);
            //3.白色晃一下
            UIInGame.ShowFlash();       

            //4.save data UI 
            if (PlayerPrefs.HasKey("BestScore"))//有这个key时
            {
                //Debug.Log("The key " + "BestScore" + " exists"); Debug出了这一行
                //存储最大分
                if (score > PlayerPrefs.GetInt("BestScore"))
                {
                    PlayerPrefs.SetInt("BestScore", score);
                }
            }
            else//无这个key 时
            {
                PlayerPrefs.SetInt("BestScore", score);
                //Debug.Log("The key " + "BestScore" + " Not exists"); 这行Debug没出
            }
            //存储金币
            PlayerPrefs.SetInt("Coin", coin + PlayerPrefs.GetInt("Coin", 100));//这局赚到的coin加上历史得到过的，
                                                                               //但是如果coin花出去了， PlayerPrefs有改变了

            //5.先存储数据，再打开结束UI
            StartCoroutine(OpenGameOver());

            //6.播放结束music
            MusicManager.Instance.isGameOver = true;
        }
    }

    /// <summary>
    /// 等待一秒再显示
    /// </summary>
    /// <returns></returns>
    IEnumerator OpenGameOver()
    {
        yield return new WaitForSeconds(0.7f);//给白色背景闪现的时间
        GUIManager.Instance.OpenPanel(3, true);//打开结束UI
    }

    /// <summary>
    /// 换装player的
    /// </summary>
    public void SelectSkin()
    {
        //把对应序号的Skins类下设置的皮肤数据的图片信息换装到player
        player.GetComponent<SpriteRenderer>().sprite = SkinManager.Instance.Skins[PlayerPrefs.GetInt("selectSkin", 0)].spriteCharacter;
    }
}

//枚举
public enum ObjectType//枚举
{
    Tile,
    Item,
    Coin,
    Enemy,
    Bullet
}

public enum GameState
{
    PAUSED,
    RUNNING,
    GAMEOVER
}
