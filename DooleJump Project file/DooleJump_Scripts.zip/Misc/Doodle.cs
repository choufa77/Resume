﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doodle : MonoBehaviour
{
    //y轴偏移量
    public float offsetY = 100;
    public float time = 0.5f;

    private void Start()
    {
        //调用iTween插件实现Doodle动画效果
        iTween.MoveBy(gameObject, iTween.Hash(
            "y", offsetY,
            "easeType", iTween.EaseType.easeInOutQuad,//变化曲线
            "loopType", iTween.LoopType.pingPong,//循环
            "time", time
            ));
    }
}
