﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowTarget : MonoBehaviour
{
    public Transform target;//位置（位于角色上面的空物体）
    Vector3 velocity = Vector3.zero;
    float damptime =0.5f;//平滑时间
    private void Update()
    {
        if (target)
        {
            Vector3 pos = Camera.main.WorldToViewportPoint(target.position);//只是为了下一语句，获得视口坐标的z值
            Vector3 delta = target.position - Camera.main.ViewportToWorldPoint(new Vector3(0.5f, 0.5f, pos.z));//会获得x、y都会变动，z为零的三维向量
            Vector3 destination = transform.position + delta;//人物跳跃的终点(x,y)

            destination.x = 0;//因为摄像头的x坐标为0，则destination.x=0，这样摄像头只在y方向上移动
            if (destination.y>transform.position.y)//空物体越过屏幕中点的世界坐标时，开始跳跃
            {
                transform.position = Vector3.SmoothDamp(transform.position, destination, ref velocity, damptime);//平滑插值
                
            }
        }
    }
}
