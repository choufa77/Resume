﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Adjust : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Resize();
    }

    void Resize()
    {
        float width = GetComponent<SpriteRenderer>().bounds.size.x;//获取该图片（平台）在x方向上的单位
        //Debug.Log("图片的宽度是" + width);  ——10.24单位
        float targetWidth = Camera.main.orthographicSize * 2 / Screen.height * Screen.width;//算出摄像头目前的宽度（单位）
        //公式：适配后的摄像头的宽度/其高度=屏幕的宽度比
        Vector3 scale = transform.localScale;//获取当前的缩放
        scale.x = targetWidth / width;//图片缩放的x值=要放大的比值
        transform.localScale = scale;
        //提醒：上面的一切改变的是scale的x值
    }
}
