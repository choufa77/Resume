﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 控制UI跳跃
/// </summary>
public class Move : MonoBehaviour
{

    //y轴偏移
    public float offsetY = 100;
    public float time = 0.5f;
    //初始位置
    Vector3 pos;

    private void Start()
    {
        pos = transform.Find("Image_Character").gameObject.transform.position;//记录一开始时的位置
    }

    private void Init()//跳跃 创建iTween
    {
        iTween.MoveBy(transform.Find("Image_Character").gameObject, iTween.Hash(  //gameObject
            "y", offsetY,
            "easeType", iTween.EaseType.easeInOutQuad,
            "loopType", iTween.LoopType.pingPong,
            "time", time
            ));

        //GetComponent<iTween>().enabled = false;  不是很正确的代码，故被取代
    }

    /// <summary>
    /// 播放动画
    /// </summary>
    public void Resume()
    {
        Init();//创建iTween

        //GetComponent<iTween>().enabled = true;
    }

    /// <summary>
    /// 暂停
    /// </summary>
    public void Pause()
    {
        //GetComponent<iTween>().enabled = false;   因为要恢复到初始位置，这行代码的运动逻辑应该就被影响了

        iTween.Stop(transform.Find("Image_Character").gameObject);//直接删除  —— 但要注意写这个“(gameObject)”，否则会把所有的iTween删掉
                                                                  //但在遍历过程中，那些没有创建iTween的,也会执行此代码

        transform.Find("Image_Character").gameObject.transform.position = pos;//恢复到初始位置    transform.position = pos;
    }
}
