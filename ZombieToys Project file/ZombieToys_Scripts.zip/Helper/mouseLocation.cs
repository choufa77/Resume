﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseLocation : MonoBehaviour
{
    public static mouseLocation Instance;

    [HideInInspector] public Vector3 MousePositon;
    [HideInInspector] public bool IsValid;

    [SerializeField] LayerMask WhatIsGround;

    Ray mouseRay;
    RaycastHit hit;
    Vector2 screenPosition;
    void Awake()
    {
        if (Instance==null)
        {
            Instance = this;
        }
        else if (Instance!=this)
        {
            Destroy(this);
        }
        
    }
 

    // Update is called once per frame
    void Update()
    {
        IsValid = false;
        screenPosition = Input.mousePosition;
        mouseRay = Camera.main.ScreenPointToRay(screenPosition);
        if (Physics.Raycast(mouseRay,out hit,100f,WhatIsGround))
        {
            IsValid = true;
            MousePositon = hit.point;
        }
    }
}
