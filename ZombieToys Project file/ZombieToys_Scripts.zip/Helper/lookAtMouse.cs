﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lookAtMouse : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        if (mouseLocation.Instance!=null&&mouseLocation.Instance.IsValid)
        {
            transform.LookAt(mouseLocation.Instance.MousePositon);
        }
    }
}
