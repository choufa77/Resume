﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class characterSpotlight : MonoBehaviour
{
    [SerializeField] GameObject spotlightPC;
    
    // Start is called before the first frame update
    void Awake()
    {
        
        spotlightPC.SetActive(true);   
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager02.Instance.Player!=null)
        {
            gameObject.SetActive(false);
        }
    }
}
