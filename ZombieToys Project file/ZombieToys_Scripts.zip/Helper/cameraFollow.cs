﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraFollow : MonoBehaviour
{
    [SerializeField] float smoothing = 5f;
    [SerializeField] Vector3 offset = new Vector3(0, 2.8f, -6.3f);

     void FixedUpdate()
    {
        Vector3 targetCamPos = GameManager02.Instance.Player.transform.position + offset;
        transform.position = Vector3.Lerp(transform.position, targetCamPos, smoothing * Time.deltaTime);
    }
}
