﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
            
public class playerSelect : MonoBehaviour   
{
    [Header("Player to Disable")]
    [SerializeField] playerSelect otherCharacter;

    [Header("References")]
    [SerializeField] playerHealth playerHealth;
    [SerializeField] Rigidbody rigidBody;
    [SerializeField] CapsuleCollider capsuleCollider;
    [SerializeField] Animator animator;

     void Reset()
    {
        playerHealth = GetComponent<playerHealth>();
        rigidBody = GetComponent<Rigidbody>();
        capsuleCollider = GetComponent<CapsuleCollider>();
        animator = GetComponent<Animator>();
    }

     void OnMouseUp()
    {
#if !UNITY_ANDROID && !UNITY_IOS && !UNITY_WP8
        //...and if the pointer is over a UI element, then leave this method without choosing a player
        //(this prevents the player from being chosen while the pause menu is open)
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            return;
#endif
        GameManager02.Instance.PlayerChosen(playerHealth);

        if (otherCharacter!=null)
        {
            otherCharacter.DisableSelectableCharacter();
        }
        enabled = false;
    }

    public void DisableSelectableCharacter()
    {
        capsuleCollider.enabled = false;
        animator.SetTrigger("Die");
    }

    void DeathComplete()
    {
        rigidBody.drag = 0f;
        Destroy(gameObject, 1f);
    }
}
