﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerInputPC : MonoBehaviour
{
    [SerializeField] playerMovement playerMovement=null ;
    [SerializeField] playerAttack playerAttack = null;
    [SerializeField] PauseMenu pauseMenu;

    void Reset()
    {
        playerMovement = GetComponent<playerMovement>();
        playerAttack = GetComponent<playerAttack>();
        pauseMenu = FindObjectOfType<PauseMenu>();
    }

    // Update is called once per frame
    void Update()
    {
        if (pauseMenu != null && Input.GetButtonDown("Cancel"))
            pauseMenu.Pause();
        if (!CanUpdate())
        {
            return;
        }
        HandleMoveInput();
        HandleAttackInput();
    }

    bool CanUpdate()
    {
        if (pauseMenu != null && pauseMenu.IsPaused)
            return false;
        if (GameManager02.Instance.Player==null||GameManager02.Instance.Player.transform!=transform)
        {
            return false;
        }
        return true;
    }
    void HandleMoveInput()
    {
        if (playerMovement==null)
        {
            return;
        }
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        playerMovement.MoveDirection = new Vector3(horizontal, 0, vertical);
        if (mouseLocation.Instance!=null&&mouseLocation.Instance.IsValid)
        {
            Vector3 lookPoint = mouseLocation.Instance.MousePositon - playerMovement.transform.position;
            playerMovement.LookDirection = lookPoint;
        }
    }

    void HandleAttackInput()
    {
        if (playerAttack==null)
        {
            return;
        }
        if (Input.GetButtonDown("SwitchAttack"))
        {
            playerAttack.SwitchAttack();
        }
        if (Input.GetButton("Fire1"))
        {
            playerAttack.Fire();
        }
        
    }


}
