﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : MonoBehaviour
{
    [HideInInspector] public Vector3 MoveDirection = Vector3.zero;
    [HideInInspector] public Vector3 LookDirection = Vector3.forward;

    [SerializeField] float speed = 6f;
    [SerializeField] Animator animator;
    [SerializeField] Rigidbody rigidBody;

    bool canMove = true;
    // Start is called before the first frame update
    void Reset()
    {
        animator = GetComponent<Animator>();
        rigidBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!canMove)
        {
            return;
        }
        MoveDirection.Set(MoveDirection.x, 0, MoveDirection.z);
        rigidBody.MovePosition(transform.position + MoveDirection.normalized * speed * Time.deltaTime);

        LookDirection.Set(LookDirection.x, 0, LookDirection.z);
        rigidBody.MoveRotation(Quaternion.LookRotation(LookDirection));
        animator.SetBool("IsWalking", MoveDirection.sqrMagnitude > 0);
    }
    public void Defeated()
    {
        canMove = false;
    }
}
