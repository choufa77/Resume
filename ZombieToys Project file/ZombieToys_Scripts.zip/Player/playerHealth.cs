﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerHealth : MonoBehaviour
{
    [Header("Health Properties")]
    [SerializeField] int maxHealth = 100;
    [SerializeField] AudioClip deathClip = null;

    [Header("Script References")]
    [SerializeField] playerMovement playerMovement;
    [SerializeField] playerAttack playerAttack;

    [Header("Components")]
    [SerializeField] Animator animator;
    [SerializeField] AudioSource audioSource;

    [Header("UI")]
    [SerializeField] FlashFade damageImage;             //Reference to the FlashFade script on the DamageImage UI element
    [SerializeField] Slider healthSlider;

    [Header("Debugging Properties")]
    [SerializeField] bool isInvulnerable=false;

    int currentHealth;

     void Reset()
    {
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        playerMovement = GetComponent<playerMovement>();
        playerAttack = GetComponent<playerAttack>();
    }

    void Awake()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(int amount)
    {
        if (!IsAlive())
        {
            return;
        }

        if (!isInvulnerable)
        {
            currentHealth -= amount;
        }


        if (damageImage != null)
            damageImage.Flash();

        
        if (healthSlider != null)
            healthSlider.value = currentHealth / (float)maxHealth;

        if (!IsAlive())
        {
            if (playerMovement!=null)
            {
                playerMovement.Defeated();
            }
            if (playerAttack!=null)
            {
                playerAttack.Defeated();
            }

            animator.SetTrigger("Die");

            if (audioSource!=null)
            {
                audioSource.clip = deathClip;
            }

            GameManager02.Instance.PlayerDied();
        }
        if (audioSource!=null)
        {
            audioSource.Play();
        }
    }

    public bool IsAlive()
    {
        return currentHealth > 0;
    }

    void DeathComplete()
    {
        if (GameManager02.Instance.Player==this)
        {
            GameManager02.Instance.PlayerDeathComplete();
        }
    }
}
