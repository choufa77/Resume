﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerAttack : MonoBehaviour
{
    [Header("Attacks")]
    [SerializeField] lightningAttack lightningAttack;
    [SerializeField] int numberOfAttacks;

    [Header("UI")]
    [SerializeField] Countdown countDown;
    
    int attackIndex = 0;
    float attackCooldown = 0f;
    float timeOfLastAttack = 0f;
    bool canAttack = true;

    
    public void SwitchAttack()
    {
        if (!canAttack)
            return;
        attackIndex++;
        if (attackIndex>=numberOfAttacks)
        {
            attackIndex = 0;
        }
        DisableAttacks();
        switch (attackIndex)
        {
            case 0:
                if (lightningAttack!=null)
                {
                    lightningAttack.gameObject.SetActive(true);
                }
                break;
        }
    }

    public void Fire()
    {
        if (!ReadyToAttack()||!canAttack)
        {
            return;
        }

        switch (attackIndex)
        {
            case 0:
                ShootLightning();
                break;
        }
    }

    public void StopFiring()
    {

    }
    void ShootLightning()
    {
        if (lightningAttack==null)
        {
            return;
        }
        lightningAttack.Fire();
        attackCooldown = lightningAttack.CoolDown;
        BeginCountdown();
    }
    bool ReadyToAttack()
    {
        return Time.time >= timeOfLastAttack + attackCooldown;
    }

    public void Defeated()
    {
        canAttack = false;
        DisableAttacks();
    }
    void BeginCountdown()
    {
        timeOfLastAttack = Time.time;

        if (countDown != null)
            countDown.BeginCountdown(attackCooldown);
    }
    void DisableAttacks()
    {
        if (lightningAttack!=null)
        {
            lightningAttack.gameObject.SetActive(false);
        }
    }
}
