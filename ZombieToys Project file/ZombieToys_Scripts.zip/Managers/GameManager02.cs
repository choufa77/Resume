﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager02 : MonoBehaviour
{
    public static GameManager02 Instance;

    [Header("Player and Enemy Properties")]
    public playerHealth Player;
    public Transform EnemyTarget;

    [SerializeField] float delayOnPlayerDeath = 1f;


    [Header("UI Properties")]
    [SerializeField] Text infoText;                
    [SerializeField] Text gameoverText;

    [Header("Player Selection Properties")]
    [SerializeField] GameObject enemySpawners;
    [SerializeField] Animator cameraAnimator;


    int score = 0;  
    void Awake()
    {
        if (Instance==null)
        {
            Instance = this;
        }
        else if (Instance!=this)
        {
            Destroy(this);
        }
    }

    public void PlayerChosen(playerHealth selected)
    {
        Player = selected;
        EnemyTarget = Player.transform;

        if (cameraAnimator!=null)
        {
            cameraAnimator.SetTrigger("Start");
        }

        if (enemySpawners != null)
            enemySpawners.SetActive(true);
    }

    public void PlayerDied()
    {
        EnemyTarget = null;

        if (gameoverText != null)
            gameoverText.enabled = true;
    }
    public void PlayerDeathComplete()
    {
        Invoke("ReloadScene", delayOnPlayerDeath);
    }

    public void AddScore(int points)
    {
        //Add points to the player's score
        score += points;
        //If the info text UI element exists, update it to say the player's score
        if (infoText != null)
            infoText.text = "Score: " + score;
        
    }
    void ReloadScene()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.buildIndex);
    }
}
