﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemySpawner : MonoBehaviour
{
    [Header("Spawner Properties")]
    [SerializeField] GameObject enemyPerfab;
    [SerializeField] float spawnRate = 5f;
    [SerializeField] int maxEnemies = 10;

    [Header("Debugging Properties")]
    [SerializeField] bool canSpawn = true;

    enemyHealth[] enemies;
    WaitForSeconds spawnDelay;

    private void Awake()
    {
        enemies = new enemyHealth[maxEnemies];
        for (int i = 0; i < maxEnemies; i++)
        {
            GameObject obj = (GameObject)Instantiate(enemyPerfab);
            enemyHealth enemy = obj.GetComponent<enemyHealth>();
            obj.transform.parent = transform;
            obj.SetActive(false);
            enemies[i] = enemy;
        }

        spawnDelay = new WaitForSeconds(spawnRate);
    }

     IEnumerator Start()
    {
        while (canSpawn)
        {
            yield return spawnDelay;
            SpawnEnemy();
        }
    }

    void SpawnEnemy()
    {
        for (int i = 0; i < enemies.Length; i++)
        {
            if (!enemies[i].gameObject.activeSelf)
            {
                enemies[i].transform.position = transform.position;
                enemies[i].transform.rotation = transform.rotation;
                enemies[i].gameObject.SetActive(true);
                return;
            }
        }
    }
}
