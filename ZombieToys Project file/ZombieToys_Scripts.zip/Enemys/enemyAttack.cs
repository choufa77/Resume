﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAttack : MonoBehaviour
{
    [SerializeField] float timeBetweenAttacks = 0.5f;
    [SerializeField] int attackDamage = 10;
    [SerializeField] Animator animator;

    bool canAttack;
    bool playerInRange;
    WaitForSeconds attackDelay;

     void Reset()
    {
        animator = GetComponent<Animator>();
    }

    private void Awake()
    {
        attackDelay = new WaitForSeconds(timeBetweenAttacks);
    }

    private void OnEnable()
    {
        canAttack = true;
        StartCoroutine("AttackPlayer");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform==GameManager02.Instance.Player.transform)
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.transform==GameManager02.Instance.Player.transform)
        {
            playerInRange = false;
        }
    }

    IEnumerator AttackPlayer()
    {
        yield return null;

        if (GameManager02.Instance==null)
        {
            yield break;
        }

        while (canAttack&&ChectPlayerStatus())
        {
            if (playerInRange)
            {
                GameManager02.Instance.Player.TakeDamage(attackDamage);
            }

            yield return attackDelay;
        }

    }

    bool ChectPlayerStatus()
    {
        if (GameManager02.Instance.Player.IsAlive())
        {
            return true;
        }

        animator.SetTrigger("PlayerDead");
        Defeated();
        return false;
    }

    public void Defeated()
    {
        canAttack = false;
    }
}
