﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyMovement : MonoBehaviour
{
    [Header("Components")]
    [SerializeField] UnityEngine.AI.NavMeshAgent navMeshAgent;
    [SerializeField] Animator animator;

    static WaitForSeconds updateDelay = new WaitForSeconds(0.5f);
    private void Reset()
    {
        navMeshAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        animator = GetComponent<Animator>();
    }

    private void OnEnable()
    {
        navMeshAgent.enabled = true;
        StartCoroutine("ChasePlayer");
    }

    IEnumerator ChasePlayer()
    {
        yield return null;

        if (GameManager02.Instance==null)
        {
            yield break;
        }

        while (navMeshAgent.enabled)
        {
            Transform target = GameManager02.Instance.EnemyTarget;
            if (target!=null)
            {
                navMeshAgent.SetDestination(target.position);
            }
            yield return updateDelay;
        }
    }

    public void Defeated()
    {
        navMeshAgent.enabled = false;
    }
}
