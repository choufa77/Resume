﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyHealth : MonoBehaviour
{
    [HideInInspector] public enemySpawner Spawner;

    [Header("Health Properties")]
    [SerializeField] int maxHealth = 100;
    [SerializeField] int scoreValue = 10;

    [Header("Defeated Effects")]
    [SerializeField] float sinkSpeed = 2.5f;
    [SerializeField] float deathEffectTime = 2f;
    [SerializeField] AudioClip deathClip = null;
    [SerializeField] AudioClip hurtClip = null;

    [Header("Script References")]
    [SerializeField] enemyAttack enemyAttack;
    [SerializeField] enemyMovement enemyMovement;

    [Header("Components")]
    [SerializeField] Animator animator;
    [SerializeField] AudioSource audioSource;
    [SerializeField] CapsuleCollider capsuleCollider;
    [SerializeField] ParticleSystem hitParticleSystem;

    [Header("Debugging Properties")]
    [SerializeField] bool isInvulnerable;

    int currentHealth;
    bool isSinking;

     void Reset()
    {
        enemyAttack = GetComponent<enemyAttack>();
        enemyMovement = GetComponent<enemyMovement>();

        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        capsuleCollider = GetComponent<CapsuleCollider>();
        hitParticleSystem = GetComponentInChildren<ParticleSystem>();
    }

     void OnEnable()
    {
        currentHealth = maxHealth;
        isSinking = false;
        capsuleCollider.isTrigger = false;

        if (audioSource!=null)
        {
            audioSource.clip = hurtClip;
        }
    }
    

    // Update is called once per frame
    void Update()
    {
        if (!isSinking)
        {
            return;
        }
        transform.Translate(-Vector3.up * sinkSpeed * Time.deltaTime);
    }

    public void TakeDamage(int amount)
    {
        if (currentHealth<=0||isInvulnerable)
        {
            return;
        }
        currentHealth -= amount;
        if (currentHealth<=0)
        {
            Defeated();
        }
        if (audioSource!=null)
        {
            audioSource.Play();
        }
        hitParticleSystem.Play();
    }

    void Defeated()
    {
        capsuleCollider.isTrigger = true;

        animator.enabled = true;
        animator.SetTrigger("Dead");

        if (audioSource!=null)
        {
            audioSource.clip = deathClip;
        }

        enemyAttack.Defeated();
        enemyMovement.Defeated();



        Invoke("TurnOFF", deathEffectTime);
    }

    void TurnOFF()
    {
        gameObject.SetActive(false);
    }

    public void StartSinking()
    {
        isSinking = true;
    }
}
