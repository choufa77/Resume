﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightningAttack : MonoBehaviour
{
    [Header("Weapon Specs")]
    public float CoolDown = 1f;

    [SerializeField] int damage = 20;
    [SerializeField] float range = 20f;
    [SerializeField] LayerMask strikeableMask;

    [Header("Weapon Reference")]
    [SerializeField] lightningBolt lightningBolt;
    [SerializeField] aVPlayer lightningHit;

    public void Fire()
    {
        Ray ray = new Ray(transform.position, transform.forward);
        RaycastHit hit;

        if (Physics.Raycast(ray,out hit ,range,strikeableMask))
        {
            lightningHit.transform.position = hit.point;
            lightningHit.Play();
            lightningBolt.EndPoint = hit.point;
            enemyHealth enemyHealth = hit.collider.GetComponent<enemyHealth>();
            if (enemyHealth != null)
            {
                enemyHealth.TakeDamage(damage);
            }
        }
        else
        {
            lightningBolt.EndPoint = ray.GetPoint(range);
        }
       
        lightningBolt.gameObject.SetActive(true);

    }
}
