﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightningBolt : MonoBehaviour
{
    [HideInInspector] public Vector3 EndPoint;

    [Header("Bolt Properties")]
    [SerializeField] float rayHeight = 2.0f;
    [SerializeField] float effectDuration = 0.75f;
    [SerializeField] float phaseDuration = 0.1f;

    [Header("Bolt rendering")]
    [SerializeField] LineRenderer rayRenderer;
    [SerializeField] AnimationCurve[] rayPhases;

    int phaseIndex = 0;
    float timeToChangePhase;
    float timeSinceEffectStarted;
    Vector3 vectorOfBolt;

     void OnEnable()
    {
        timeToChangePhase = 0f;
        timeSinceEffectStarted = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        timeSinceEffectStarted += Time.deltaTime;
        if (timeSinceEffectStarted>=effectDuration)
        {
            gameObject.SetActive(false);
        }
        vectorOfBolt = EndPoint - transform.position;
        if (timeSinceEffectStarted>=timeToChangePhase)
        {
            timeToChangePhase = timeSinceEffectStarted +phaseDuration;
            ChangePhase();
        }
    }
    void ChangePhase()
    {
        
        phaseIndex++;
       
        if (phaseIndex >= rayPhases.Length)
            phaseIndex = 0;

        
        AnimationCurve curve = rayPhases[phaseIndex];
        
        rayRenderer.positionCount = curve.keys.Length;
        
        for (int index = 0; index < curve.keys.Length; ++index)
        {
            
            Keyframe key = curve.keys[index];

           
            Vector3 point = transform.position + vectorOfBolt * key.time;
           
            point += Vector3.up * key.value * rayHeight;
           
            rayRenderer.SetPosition(index, point);
        }
    }
}
